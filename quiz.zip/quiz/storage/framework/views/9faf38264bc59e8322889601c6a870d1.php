

<?php $__env->startSection('content'); ?>

<form method="POST" action="<?php echo e(route('process.quiz')); ?>" class="quiz-form">
    <?php echo csrf_field(); ?>
    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="question-container mt-4">
            <p class="question-number">Questão <?php echo e($index + 1); ?></p>
            <p class="question-text"><?php echo e($question->tema); ?></p>
            <p class="question-text"><?php echo e($question->question); ?></p>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="<?php echo e($question->id); ?>" value="A" id="optionA<?php echo e($question->id); ?>">
                <label class="form-check-label" for="optionA<?php echo e($question->id); ?>">
                <?php echo e($question->option_a); ?>

                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="<?php echo e($question->id); ?>" value="B" id="optionB<?php echo e($question->id); ?>">
                <label class="form-check-label" for="optionB<?php echo e($question->id); ?>">
                   <?php echo e($question->option_b); ?>

                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="<?php echo e($question->id); ?>" value="C" id="optionC<?php echo e($question->id); ?>">
                
                <label class="form-check-label" for="optionC<?php echo e($question->id); ?>">
                    <?php echo e($question->option_c); ?>

                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="<?php echo e($question->id); ?>" value="D" id="optionD<?php echo e($question->id); ?>">
                <label class="form-check-label" for="optionD<?php echo e($question->id); ?>">
                    <?php echo e($question->option_d); ?>

                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="<?php echo e($question->id); ?>" value="E" id="optionE<?php echo e($question->id); ?>">
                <label class="form-check-label" for="optionE<?php echo e($question->id); ?>">
                    <?php echo e($question->option_e); ?>

                </label>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <button type="submit" class="btn btn-primary submit-btn">finalizar</button>
</form>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\QuizMaster\quiz\resources\views\quiz.blade.php ENDPATH**/ ?>