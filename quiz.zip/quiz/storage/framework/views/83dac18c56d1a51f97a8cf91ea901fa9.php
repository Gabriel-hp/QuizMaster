

<?php $__env->startSection('content'); ?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
        <div class="card text-center">
    <div class="card-header bg-primary text-white">
        <h2 class="mb-0">Resultado do Quiz</h2>
    </div>
    <div class="card-body">
        <h3 class="card-title">Seu Resultado:</h3>
        <p class="display-4 font-weight-bold 
            <?php if($score < ($totalQuestions * 0.5)): ?> text-danger
            <?php elseif($score < ($totalQuestions * 0.7)): ?> text-warning
            <?php else: ?> text-success
            <?php endif; ?>">
            <?php echo e($score); ?> de <?php echo e($totalQuestions); ?>

        </p>
        
        <?php if($score < ($totalQuestions * 0.5)): ?>
            <p class="card-text text-danger">Não desanime! Continue praticando para melhorar seu desempenho.</p>
        <?php elseif($score < ($totalQuestions * 0.7)): ?>
            <p class="card-text text-warning">Bom esforço! Com mais prática, você pode melhorar ainda mais.</p>
        <?php else: ?>
            <p class="card-text text-success">Parabéns! Continue praticando para manter e melhorar seu desempenho.</p>
        <?php endif; ?>
        
        <a href="<?php echo e(route('quiz')); ?>" class="btn btn-lg btn-primary mt-3">Tentar Novamente</a>
    </div>
</div>


            <div class="card mt-5">
                <div class="card-header bg-secondary text-white">
                    <h3 class="mb-0">Revisão das Questões</h3>
                </div>
                <div class="card-body">
                    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="question-review mb-4">
                            <p><strong>Questão <?php echo e($index + 1); ?>:</strong> <?php echo e($question->question); ?></p>
                            <p><strong>Sua Resposta:</strong> 
                                <span class="<?php if($userAnswers[$question->id] == $question->correct_option): ?> text-success <?php else: ?> text-danger <?php endif; ?> ">
                                    <?php echo e($userAnswers[$question->id] ?? 'Não respondida'); ?>

                                </span>
                            </p>
                            <p><strong>Resposta Correta:</strong> <span class="text-success"><?php echo e($question->correct_option); ?></span></p>
                            <hr>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\QuizMaster\quiz\resources\views\result.blade.php ENDPATH**/ ?>