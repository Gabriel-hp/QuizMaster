

<?php $__env->startSection('content'); ?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h2 class="mb-0">Configurar Quiz</h2>
                </div>
                <div class="card-body">
                    <form method="GET" action="<?php echo e(route('quiz')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="categories">Escolha as Categorias:</label>
                            <div class="form-check">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="checkbox" name="categories[]" id="category<?php echo e($category); ?>" value="<?php echo e($category); ?>">
                                        <label class="form-check-label" for="category<?php echo e($category); ?>">
                                            <?php echo e($category); ?>

                                        </label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-group">
                                <label for="tema">Selecione a banca:</label>
                                <select name="tema" id="tema" class="form-control">
                                    <?php $__currentLoopData = $temas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tema): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($tema); ?>"><?php echo e($tema); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="form-group mt-3">
                            <label for="quantity">Quantidade de Perguntas:</label>
                            <input type="number" name="quantity" id="quantity" class="form-control" min="1" max="100" value="10">
                        </div>

                        <button type="submit" class="btn btn-primary mt-3">Iniciar Quiz</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\QuizMaster\quiz\resources\views/quiz_options.blade.php ENDPATH**/ ?>